from setuptools import setup

setup(
    name='ft_package',
    version='0.0.1',
    # packages=['ft_package'],
    install_requires=[],
	author='hasabir',  # Replace with your name
    author_email='hasabir@student.1337.ma ',  # Replace with your email
    description='A sample test package', 
    license='MIT',
	url='https://github.com/eagle/ft_package'
	# other arguments
)



# setup(
#     name='your_package_name',  # Replace with your package name
#     version='0.1',  # Replace with your package version
#     packages=find_packages(),  # Automatically find and include all packages
#     install_requires=[],  # Add your dependencies here, e.g., ['numpy', 'requests']
    
#     # Additional metadata (optional but recommended)
     
#     long_description=open('README.md').read(),  # Long description from README file
#     long_description_content_type='text/markdown',  # Content type of long description
#     url='https://github.com/yourusername/your-repo',  # Replace with your project URL
#     classifiers=[  # Optional classifiers
#         'Programming Language :: Python :: 3',
#         'License :: OSI Approved :: MIT License',
#         'Operating System :: OS Independent',
#     ],
#     python_requires='>=3.6',  # Specify the Python versions you support
# )
